scp -P 22 /Users/Shared/Project/Learn_2019/WOW-Web/wow.zip root@129.211.39.173:/ftp-file \
&& autossh 2 \
&& docker cp /ftp-file/wow.zip wow-web-node:var/wow-web
&& docker exec -it wow-web-node bash
&& 